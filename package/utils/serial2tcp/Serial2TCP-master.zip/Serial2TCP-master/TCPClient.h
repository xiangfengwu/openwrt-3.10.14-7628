#ifndef __TCPCLIENT_H__
#define __TCPCLIENT_H__


#define DEST_PORT 8000
#define DEST_IP_ADDRESS "192.168.137.1"

void maintest(void);
#endif
